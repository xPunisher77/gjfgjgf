module.exports = {
  prefix: "/",
  owner: "1055157768719454338",
  serverip: "141.95.225.55",
  ip: "http://141.95.225.55/",
  token: "MTA1ODEwMDMyODAxNDI4Njg1OQ.Gxv5xx.R2qiK7wQWu5iLd0dQCaKtEY2z16tKPXpvEWHvg"
}